Targa Pylon by a_midgett on Thingiverse: https://www.thingiverse.com/thing:847738

Summary:
Enemy mini for the Shadows of Brimstone: City of the Ancients board game.  40mm base.  (See instructions for assembly)